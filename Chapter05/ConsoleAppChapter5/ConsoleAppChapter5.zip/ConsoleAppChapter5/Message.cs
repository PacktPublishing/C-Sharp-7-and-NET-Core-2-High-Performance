﻿namespace ConsoleAppChapter5
{
    public class Message
    {
        public int MessageID { get; set; }
        public string MessageSubject { get; set; }
        public string MessageBody { get; set; }
        public string MessageTo { get; set; }
        public string MessageFrom { get; set; }
    }
}