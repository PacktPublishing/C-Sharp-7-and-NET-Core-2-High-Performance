﻿namespace ConsoleAppChapter5
{
    public class Person
    {
        public int ID { get; set; }
        public string Name { get; set; }
        public string Email { get; set; }

    }
}