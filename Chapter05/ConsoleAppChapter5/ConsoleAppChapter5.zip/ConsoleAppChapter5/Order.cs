﻿using System;

namespace ConsoleAppChapter5
{
    public class Order
    {

        public int OrderNo { get; set; }
        public DateTime OrderTime { get; set; }
        public string OrderDetails { get; set; }
        public string ClientContact { get; set; }

    }
}