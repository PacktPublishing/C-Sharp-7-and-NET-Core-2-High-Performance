﻿namespace ConsoleAppChapter5
{
    internal class Document
    {
    }
}