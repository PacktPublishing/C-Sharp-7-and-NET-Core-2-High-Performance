﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using App.Metrics.AspNetCore;
using App.Metrics;

namespace SampleWebApp
{
    public class Program
    {
        public static void Main(string[] args)
        {
            BuildWebHost(args).Run();
        }

        public static IWebHost BuildWebHost(string[] args)
        {
            //var metric = new MetricsBuilder();
            //var metricRoot= metric.Configuration.Configure(
            //   options =>
            //   {
            //       options.Enabled = true;
            //       options.ReportingEnabled = true;

            //       options.WithGlobalTags((globalTags, info) =>
            //       {
            //           globalTags.Add("app", "SampleWebApp");
            //           globalTags.Add("env", "stage");
            //           globalTags.Add("server", Environment.MachineName);
            //       });
            //   })
            //   .Report.ToInfluxDb(
            //       options =>
            //       {
            //           options.InfluxDb.BaseUri = new Uri("http://localhost:8086");
            //           options.InfluxDb.Database = "samplewebdb";
            //           options.InfluxDb.UserName = "ovais";
            //           options.InfluxDb.Password = "P@ssw0rd";
            //           options.HttpPolicy.BackoffPeriod = TimeSpan.FromSeconds(30);
            //           options.HttpPolicy.FailuresBeforeBackoff = 5;
            //           options.HttpPolicy.Timeout = TimeSpan.FromSeconds(10);
            //           options.FlushInterval = TimeSpan.FromSeconds(5);
            //       })
            //   .Build();


            
          //var metric = new MetricsBuilder();
          //var metricRoot = metric
          //.Configuration.Configure(
          //options =>
          //{
          //    options.WithGlobalTags((globalTags, info) =>
          //    {
          //        globalTags.Add("app", info.EntryAssemblyName);
          //        globalTags.Add("env", "stage");
          //      //  globalTags.Add("server", Environment.MachineName);
          //    });
          //})
          //.Report.ToInfluxDb(
          //    options =>
          //    {
          //        options.InfluxDb.BaseUri = new Uri("http://localhost:8086");
          //        options.InfluxDb.Database = "appmetricsdb";
          //        options.InfluxDb.UserName = "ovais";
          //        options.InfluxDb.Password = "P@ssw0rd";
          //        options.HttpPolicy.BackoffPeriod = TimeSpan.FromSeconds(30);
          //        options.HttpPolicy.FailuresBeforeBackoff = 5;
          //        options.HttpPolicy.Timeout = TimeSpan.FromSeconds(10);
          //    })
          //.Build();


            var webHost = WebHost.CreateDefaultBuilder(args)
             //   .UseMetrics()
                //.UseMetricsWebTracking()
                .UseStartup<Startup>()
                .Build();
            return webHost;
        }
    }
}
