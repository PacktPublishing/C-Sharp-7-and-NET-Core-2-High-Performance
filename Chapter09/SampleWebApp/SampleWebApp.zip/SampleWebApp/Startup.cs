using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.AspNetCore.Mvc;
using App.Metrics;

namespace SampleWebApp
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            var metrics = new MetricsBuilder()
           .Configuration.Configure(
           options =>
           {
               options.WithGlobalTags((globalTags, info) =>
               {
                   globalTags.Add("app", info.EntryAssemblyName);
                   globalTags.Add("env", "stage");
                 //  globalTags.Add("server", Environment.MachineName);
               });
           })
           .Report.ToInfluxDb(
               options =>
               {
                   options.InfluxDb.BaseUri = new Uri("http://127.0.0.1:8086");
                   options.InfluxDb.Database = "appmetricsdb";
                   //options.InfluxDb.UserName = "ovais";
                   //options.InfluxDb.Password = "P@ssw0rd";
                   //options.HttpPolicy.BackoffPeriod = TimeSpan.FromSeconds(30);
                   //options.HttpPolicy.FailuresBeforeBackoff = 5;
                   options.HttpPolicy.Timeout = TimeSpan.FromSeconds(10);
               })
           .Build();
            services.AddMetrics(metrics);
            services.AddMetricsReportScheduler();

            services.AddMetricsTrackingMiddleware();
            
             services.AddMvc(options => options.AddMetricsResourceFilter());
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IHostingEnvironment env, IApplicationLifetime lifetime)
        {
            if (env.IsDevelopment())
            {
                app.UseBrowserLink();
                app.UseDeveloperExceptionPage();
            }
            else
            {
                app.UseExceptionHandler("/Error");
            }

            app.UseStaticFiles();

            app.UseMetricsAllMiddleware();


            //app.UseMetricsApdexTrackingMiddleware();
            //app.UseMetricsRequestTrackingMiddleware();
            //app.UseMetricsErrorTrackingMiddleware();
            //app.UseMetricsActiveRequestMiddleware();
            //app.UseMetricsPostAndPutSizeTrackingMiddleware();
            //app.UseMetricsOAuth2TrackingMiddleware();

            //app.UseMetricsAllEndpoints();
            // Or to cherry-pick endpoint of interest
            //app.UseMetricsEndpoint();
            //app.UseMetricsTextEndpoint();
            //app.UseEnvInfoEndpoint();         
            app.UseMvc();
        }
    }
}
