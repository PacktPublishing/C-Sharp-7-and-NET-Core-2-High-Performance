﻿namespace ConsoleAppThreads
{
    public interface IPerson
    {
        string Name { get; set; }
    }
}