﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Chapter6MemAlloc
{
    class DatabaseManagerFinalizer
    {
    }
}
