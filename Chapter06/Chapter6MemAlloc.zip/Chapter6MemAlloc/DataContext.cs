﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Text;

namespace Chapter6MemAlloc
{
    public class DataContext : DbContext
    {
        //Define DBSet for POCO entities 

    }
}
