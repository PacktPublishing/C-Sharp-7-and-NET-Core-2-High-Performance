``` ini

BenchmarkDotNet=v0.10.9, OS=Windows 10 Redstone 2 (10.0.15063)
Processor=Intel Core i7-4900MQ CPU 2.80GHz (Haswell), ProcessorCount=8
Frequency=2728057 Hz, Resolution=366.5613 ns, Timer=TSC
.NET Core SDK=2.0.0
  [Host] : .NET Core 2.0.0 (Framework 4.6.00001.0), 64bit RyuJIT DEBUG

There are no benchmarks found 

